﻿using System;

class Programa
{
    static char[] tabuleiro = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    static int jogador = 1; // 1 - jogador, 2 - computador
    static int escolha;
    static int vitoria = 0; // 0 - nenhum vencedor, 1 - jogador, 2 - computador
    static int turno = 0; // número de movimentos

    static void Main()
    {
        Console.WriteLine("Bem-vindo ao Jogo da Velha!");
        Console.WriteLine("Escolha o modo de jogo:");
        Console.WriteLine("1 - JOGADOR 1 VS JOGADOR 2");
        Console.WriteLine("2 - JOGADOR 1 VS MÁQUINA");
        int modo = Convert.ToInt32(Console.ReadLine());

        do
        {
            Console.Clear();
            MostrarTabuleiro();

            if (modo == 1 || jogador == 1)
            {
                Console.WriteLine("Jogador {0}, escolha uma posição entre 1 e 9", jogador);
                escolha = Convert.ToInt32(Console.ReadLine());
                if (tabuleiro[escolha] != 'X' && tabuleiro[escolha] != 'O')
                {
                    tabuleiro[escolha] = jogador == 1 ? 'X' : 'O';
                    turno++;
                    jogador = (jogador % 2) + 1;
                }
                else
                {
                    Console.WriteLine("Posição já ocupada. Tente novamente.");
                    Console.ReadLine();
                }
            }
            else if (modo == 2 && jogador == 2)
            {
                Console.WriteLine("Máquina está jogando...");
                MovimentoMaquina();
                turno++;
                jogador = (jogador % 2) + 1;
            }

            vitoria = VerificarVitoria();
        }
        while (vitoria == 0 && turno < 9);

        Console.Clear();
        MostrarTabuleiro();

        if (vitoria == 1)
            Console.WriteLine("Jogador 1 (X) venceu!");
        else if (vitoria == 2)
            Console.WriteLine("Jogador 2 (O) venceu!");
        else
            Console.WriteLine("Empate!");

        Console.ReadLine();
    }

    static void MostrarTabuleiro()
    {
        Console.WriteLine("Tabuleiro:");
        Console.WriteLine(" {0} | {1} | {2} ", tabuleiro[1], tabuleiro[2], tabuleiro[3]);
        Console.WriteLine("---+---+---");
        Console.WriteLine(" {0} | {1} | {2} ", tabuleiro[4], tabuleiro[5], tabuleiro[6]);
        Console.WriteLine("---+---+---");
        Console.WriteLine(" {0} | {1} | {2} ", tabuleiro[7], tabuleiro[8], tabuleiro[9]);
    }

    static int VerificarVitoria()
    {
        #region Condições de vitória

        if (tabuleiro[1] == tabuleiro[2] && tabuleiro[2] == tabuleiro[3])
            return (tabuleiro[1] == 'X') ? 1 : 2;
        if (tabuleiro[4] == tabuleiro[5] && tabuleiro[5] == tabuleiro[6])
            return (tabuleiro[4] == 'X') ? 1 : 2;
        if (tabuleiro[7] == tabuleiro[8] && tabuleiro[8] == tabuleiro[9])
            return (tabuleiro[7] == 'X') ? 1 : 2;

        if (tabuleiro[1] == tabuleiro[4] && tabuleiro[4] == tabuleiro[7])
            return (tabuleiro[1] == 'X') ? 1 : 2;
        if (tabuleiro[2] == tabuleiro[5] && tabuleiro[5] == tabuleiro[8])
            return (tabuleiro[2] == 'X') ? 1 : 2;
        if (tabuleiro[3] == tabuleiro[6] && tabuleiro[6] == tabuleiro[9])
            return (tabuleiro[3] == 'X') ? 1 : 2;

        if (tabuleiro[1] == tabuleiro[5] && tabuleiro[5] == tabuleiro[9])
            return (tabuleiro[1] == 'X') ? 1 : 2;
        if (tabuleiro[3] == tabuleiro[5] && tabuleiro[5] == tabuleiro[7])
            return (tabuleiro[3] == 'X') ? 1 : 2;

        return 0;
        #endregion
    }

    static void MovimentoMaquina()
    {
        Random aleatorio = new Random();
        int movimento = aleatorio.Next(1, 10);
        while (tabuleiro[movimento] == 'X' || tabuleiro[movimento] == 'O')
        {
            movimento = aleatorio.Next(1, 10);
        }
        tabuleiro[movimento] = 'O';
    }
}
